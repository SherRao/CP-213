package cp213;

import java.util.ArrayList;

/**
 * Implements a Binary Search Tree.
 *
 * @author Nausher Rao
 * @author David Brown
 * @version 2021-03-18
 */
public class BST<T extends Comparable<T>> {
    protected int comparisons = 0; // Count of comparisons performed by tree.

    // Attributes.
    protected TreeNode<T> root = null; // Root node of the tree.
    protected int size = 0; // Number of elements in the tree.

    /**
     * Auxiliary method for {@code equals}. Determines whether two subtrees are
     * identical in data and height.
     *
     * @param source Node of this BST.
     * @param target Node of that BST.
     * @return true if source and target are identical in data and height.
     */
    protected boolean equalsAux(final TreeNode<T> source, final TreeNode<T> target) {
    	boolean equals = false;
    	if(source == null && target == null)
            equals = true;

    	else if(source != null && target != null && source.getValue().compareTo(target.getValue()) == 0 && source.getHeight() == target.getHeight())
    		equals = equalsAux(source.getLeft(), target.getLeft()) && equalsAux(source.getRight(), target.getRight());

    	else
    		equals = false;
        
    	return equals;
    }

    /**
     * Auxiliary method for {@code insert}. Inserts data into this BST.
     *
     * @param node the current node (TreeNode)
     * @param data data to be inserted into the node
     * @return the inserted node.
     */
    protected TreeNode<T> insertAux(TreeNode<T> node, final CountedData<T> data) {
        // Base case: Add a new node containing the value.
        if(node == null) { 
           node = new TreeNode<T>(data);

        // Compare the node data against the new value.
        } else { 
            int a = data.compareTo(node.getValue());
            if(a == 0)
                node.getValue().incrementCount();
            
            else if(a < 0) 
                insertAux(node.getLeft(), data); // General case: Check the left subtree.
    
            else 
                insertAux(node.getRight(), data); // General case: Check the left subtree.
        }
    
        size++;
        node.updateHeight();
        
        return node;
    }

    /**
     * Auxiliary method for {@code valid}. Determines if a subtree based on node is
     * a valid subtree.
     *
     * @param node The root of the subtree to test for validity.
     * @return true if the subtree base on node is valid, false otherwise.
     */
    protected boolean isValidAux(final TreeNode<T> node) {
    	boolean valid = true;
    	if(node == null)
            valid = true;

        else if(node.getLeft() != null && max(node.getLeft()).compareTo(node.getValue()) > 0)
        	valid = false;

    	else if(node.getRight() != null && min(node.getRight()).compareTo(node.getValue()) < 0)
    		valid = false;

        else if(!(isValidAux(node.getLeft())) || !(isValidAux(node.getRight())))
        	valid = false;
        
        else 
        	valid = true;
    	
    	return valid;

    }
    
    private CountedData<T> max(TreeNode<T> node) {
    	TreeNode<T> curr = node;
    	while(curr.getRight() != null) 
    		curr = curr.getRight();
    	
    	return curr.getValue();	
    }

    private CountedData<T> min(TreeNode<T> node) {
    	TreeNode<T> curr = node;
    	while(curr.getLeft() != null) 
    		curr = curr.getLeft();
    	
    	return curr.getValue();	
    }
    
    /**
     * Returns the height of a given TreeNode.
     *
     * @param node The TreeNode to determine the height of.
     * @return The value of the height attribute of node, 0 if node is null.
     */
    protected int nodeHeight(final TreeNode<T> node) {
	    int height = 0;
    	if(node != null) 
            height = node.getHeight();
	    
	    return height;
    }

    /**
     * Determines if this BST contains key.
     *
     * @param key The key to search for.
     * @return true if this BST contains key, false otherwise.
     */
    public boolean contains(final CountedData<T> key) {
    	TreeNode<T> node = root;
    	boolean contains = false;
    	while(node != null) {
    		int comp = node.getValue().compareTo(key);
    		if(comp == 0)
    			contains = true;
    		
    		else if(comp > 0)
    			node = node.getLeft();
    		
    		else node = node.getRight();
    	}
    	
    	return contains;
    }

    /**
     * Determines whether two BSTs are identical.
     *
     * @param target The BST to compare this BST against.
     * @return true if this BST and that BST contain nodes that match in position,
     *         value, count, and height, false otherwise.
     */
    public boolean equals(final BST<T> target) {
	    boolean isEqual = false;
	    if(this.size == target.size) 
	        isEqual = this.equalsAux(this.root, target.root);

	    return isEqual;
    }

    /**
     * Get number of comparisons executed by the {@code retrieve} method.
     *
     * @return comparisons
     */
    public int getComparisons() {
	    return this.comparisons;
    }

    /**
     * Returns the height of the root node of this BST.
     *
     * @return height of root node, 0 if the root node is null.
     */
    public int getHeight() {
    	int height = 0;
        if(this.root != null)
	        height = this.root.getHeight();

        return height;
    }

    /**
     * Returns the number of nodes in the BST.
     *
     * @return number of node in this BST.
     */
    public int getSize() {
	    return this.size;
    }

    /**
     * Returns an array of copies of CountedData objects in a linked data
     * structure. The array contents are in data order from smallest to largest.
     *
     * Not thread safe as it assumes contents of data structure are not changed by
     * an external thread during the copy loop. If data elements are added or
     * removed by an external thread while the data is being copied to the array,
     * then the declared array size may no longer be valid.
     *
     * @return this tree data as an array of data.
     */
    public ArrayList<CountedData<T>> inOrder() {
    	if(root == null)
    		return null;
    	
	    return this.root.inOrder();
    
    }

    /**
     * Inserts data into this BST.
     *
     * @param data Data to store.
     */
    public void insert(final CountedData<T> data) {
        this.insertAux(this.root, data);

    }

    /**
     * Determines if this BST is empty.
     *
     * @return true if this BST is empty, false otherwise.
     */
    public boolean isEmpty() {
	    return this.root == null;
    }

    /**
     * Determines if this BST is a valid BST; i.e. a node's left child data is
     * smaller than its data, and its right child data is greater than its data, and
     * a node's height is equal to the maximum of the heights of its two children
     * (empty child nodes have a height of 0), plus 1.
     *
     * @return true if this BST is a valid BST, false otherwise.
     */
    public boolean isValid() {
	    return this.isValidAux(this.root);
    }

    /**
     * Returns an array of copies of CountedData objects int a linked data
     * structure. The array contents are in level order starting from the root
     * (this) node. Helps determine the structure of the tree.
     *
     * Not thread safe as it assumes contents of data structure are not changed by
     * an external thread during the copy loop. If data elements are added or
     * removed by an external thread while the data is being copied to the array,
     * then the declared array size may no longer be valid.
     *
     * @return this tree data as an array of data.
     */
    public ArrayList<CountedData<T>> levelOrder() {
	    return this.root.levelOrder();
    }

    /**
     * Resets the comparison count to 0.
     */
    public void resetComparisons() {
    	this.comparisons = 0;

    }

    /**
     * Retrieves a copy of data matching key data (key should have data
     * count of 0). Returning a complete CountedData gives access to the
     * data and count.
     *
     * @param key The key to look for.
     * @return data The complete CountedData that matches key, null otherwise.
     */
    public CountedData<T> retrieve(final CountedData<T> key) {
        TreeNode<T> node = this.root;
        CountedData<T> result = null;
        while(result == null && node != null) {
            int a = node.getValue().compareTo(key);
            if(a > 0)
                node = node.getLeft();

            else if(a < 0) 
                node = node.getRight();

            else 
                result = node.getValue();
        }

        return result;
    }
}
