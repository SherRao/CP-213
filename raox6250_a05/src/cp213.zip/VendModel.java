package cp213;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Vending machine model. Contains the algorithms for vending products, handling
 * change and inventory, and working with credit. Should not perform any GUI
 * work of any kind.
 *
 * @author Nausher Rao
 * @version 2021-03-19
 */
public class VendModel {

	public enum ButtonType { NUMBER, CASH, CARD, ADD_ITEM, CANCEL };
	
    private Random random;
	private ArrayList<Product> stock;
    private int row;
    private int columns;
    private String[] denominations;
    private float totalCash;
    
    private int inputSlot;
    private ArrayList<Product> purchaseList;
    private float totalCost;

    /** Try to set the look and feel to WinUI */
    static {
    	 try { 
             UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
             
         } catch (Exception e) { 
        	 System.err.println("Couldn't change the System look and feel. Check the stacktrace.");
        	 e.printStackTrace(); 
        	 
         }
    }
    
    public VendModel() {
        this.random = new Random(System.currentTimeMillis());	
        this.stock = new ArrayList<>();
        this.row = 4;
        this.columns = 6;
        this.denominations = new String[] {"5c", "10c", "25c", "50c", "$1", "$2", "$5", "$10", "Done" };
        
        this.inputSlot = 0;
        this.purchaseList = new ArrayList<>();
        
        for(int i = 0; i < row * columns; i++) {
        	int index = random.nextInt(Product.ITEM_NAMES.length);
        	stock.add(new Product( Product.ITEM_NAMES[index], random.nextInt(11), 1 + random.nextFloat() * 9, Product.ITEM_IMAGES[index] ));
        
        }
        
        this.totalCash = (random.nextFloat() * 10000) + 1000;
        System.out.println(totalCash);
    }
    
	public String buttonPress(ButtonType type, String... args) {
		switch(type) {
			case NUMBER:
				if(inputSlot == 0 || inputSlot >= 10) {
					inputSlot = Integer.parseInt(args[0]);
				
				} else {
					inputSlot *= 10;
					inputSlot += Integer.parseInt(args[0]);

				}  
				
				return "Select Item: " + inputSlot;
				
			case CASH:
				if(purchaseList.size() > 0) {
					payByCash();
					return " ";
					
				} else {
					Toolkit.getDefaultToolkit().beep();
					return "No items to purchase!";
				
				} 
				
			case CARD:
				if(purchaseList.size() > 0) {
					return payByCard();
					
				} else {
					Toolkit.getDefaultToolkit().beep();
					return "No items to purchase!";
				
				}
				
			case ADD_ITEM:
				if(inputSlot > 0 && inputSlot <= 24) {
					Product product = stock.get(inputSlot - 1);
					if(product.amount > 0) {
						product.amount -= 1;
						stock.set(inputSlot, product);
						purchaseList.add(product);
						return "Added Item: " + product.name;
						
					} else {
						Toolkit.getDefaultToolkit().beep();
						return "Out of stock!";
					}
					
					
				} else {
					Toolkit.getDefaultToolkit().beep();
					return "Invalid Input: " + inputSlot;
					
				}
				
		case CANCEL:
			clear();
			return "Cancelled Order!";
			
		}

		return null;
	}
	
	public void payByCash() {
		AtomicBoolean done = new AtomicBoolean(false);
		AtomicInteger cash = new AtomicInteger(0);
		SwingUtilities.invokeLater( () -> {
			loop:
			while(!done.get()) {
				int input = JOptionPane.showOptionDialog(null, "What cash would you like to use?\nCurrent: $" + (cash.get() / 100.00), "Pay By Cash", 
						JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, denominations, null);
				switch(input) {
					case 8:
						if(cash.get() >= totalCost)
							done.set(true);
							
						else break loop;
							
					case 0:
						cash.addAndGet(5);
						break;
						
					case 1:
						cash.addAndGet(10);
						break;		
						
					case 2:
						cash.addAndGet(25);
						break;		
						
					case 3:
						cash.addAndGet(50);
						break;		
						
					case 4:
						cash.addAndGet(100);
						break;		
						
					case 5:
						cash.addAndGet(200);
						break;	
						
					case 6:
						cash.addAndGet(500);
						break;	
						
					case 7:
						cash.addAndGet(1000);
						break;
				}
			}
		} );
		
		System.out.println(done.get());
		if(done.get()) {
			JOptionPane.showConfirmDialog(null, "Your transaction was sucessful!");
			System.exit(0);
			
		} else 
			JOptionPane.showMessageDialog(null, "You didn't deposit enough money!");

	}
	
	public String payByCard() {
		AtomicInteger totalDelay = new AtomicInteger((random.nextInt(20) + 20) * 1000);
		JLabel label = new JLabel("Please wait");
		SwingUtilities.invokeLater( () -> { JOptionPane.showConfirmDialog(null, "Test"); } );
		SwingUtilities.invokeLater( () -> {
			try {
				while(totalDelay.get() > 0) {
					label.setText(label.getText() + ".");
					
					totalDelay.addAndGet(-500);
					Thread.sleep(500);
				
				}
				
			} catch (InterruptedException e) { e.printStackTrace(); }
		} );
		
		return null;
	}
	
	public void clear() {
		totalCash += totalCost;
		totalCost = 0;
		for(Product product : purchaseList) 
			
		
	}
	
	
    public ArrayList<Product> getStock() {
        return this.stock;

    }
	
}
